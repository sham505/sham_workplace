/*Global Variables Section*/
var entryIndicator=true;
//Declare your Global Variables inside this block
/*End of Global Variables*/

// A $(document).ready() block. 
$(document).ready(function() {
	getProducts(); // Function call to load products when the application is
					// loaded
});

// Get List of Products from the database
function getProducts() {
	/***************************************************************************
	 * Code for fetching the list of product from the database
	 **************************************************************************/
	 var catogeryList = [];
	$
			.ajax({
				type : 'GET',
				dataType : 'json',
				url : 'http://localhost:3000/products',
				success : function(product) {
					if (product.data.length > 0) { // If Ajax request feteched
													// products
						$
								.each(
										product.data,
										function(key, value) { // Iterating
																// through the
																// JSON object
																// and appending
																// all the
																// products to
																// the container
																// ProductsList
											var filePath = value.productImg.filePath
													.replace('./public', '..');

											$('#ProductsList')
													.append(
															'<div  class="CustomMargin" id="'
																	+ value._id
																	+ '"><div class="row"><div class="col-sm-4"><input type="file" class="imageInp" id="imageInp-'
																	+ value._id
																	+ '" onchange="readURL(this);" style= "display: none;"/><a href="javascript:;" title="click to update the image"><img src="'
																	+ filePath
																	+ '" class="image" height="100%" width="100%" id="image-'
																	+ value._id
																	+ '" alt = "your image"></a><a href="#" class="href-cls" id ="upload-'
																	+ value._id
																	+ '" ><span class="glyphicon glyphicon-open" style="left: 75px;">Upload</span></a></div><div class="col-sm-8"><h4 id="name-'
																	+ value._id
																	+ '">'
																	+ value.name
																	+ '</h4><p id="description-'
																	+ value._id
																	+ '">'
																	+ value.description
																	+ '</p><label class="CustomBG1 CategoryName" id="category-'
																	+ value._id
																	+ '">'
																	+ value.category
																	+ '</label><br><h4 class="text-danger" id="price-'
																	+ value._id
																	+ '"> Rs: '
																	+ value.price
																	+ '</h4></div></div><div class = "row"></div><div class="row CustomBG1"><button type="button" id="edit-'
																	+ value._id
																	+ '" class="btn btn-success pull-right edit" style="margin-top:5px"><span class="glyphicon glyphicon-edit">Edit</button><button type="button" id="remove-'
																	+ value._id
																	+ '" data-toggle="modal" data-target="#confirm-delete" class="btn btn-danger pull-right" style="margin-top:5px"><span class="glyphicon glyphicon-trash"></span> Remove</button></div></div><br>')
																catogeryList.push(value.category);
										});
										
										catogeryList=jQuery.unique(catogeryList);
		
										$.each(catogeryList, function(index, value) {
            
										$('#draggablezone').append('<a id="Category-'+value+'"type="button" class="btn btn-success pull-left"  draggable="true" ondragleave="allowDrop1(event)" ondragstart="drag(event)" style="margin-top:5px">'+value+'</a>')
																			});
					} else { // displaying message in case no products are
								// available in the database
						$('#ProductsList')
								.append(
										'<div class="alert alert-danger" style="display:flex;"> No products available to display</div>');
					}
				},
				error : function(jqXHR, exception) { // displaying error
														// message in case of
														// exception in
														// connecting to the
														// database
					$('#ProductsList')
							.append(
									'<div class="alert alert-danger" style="display:flex;"> <h5>Error in fetching the products list. Please try after sometime</h5></div>');
				}
			})
}

$(document).on('click', '.edit', editProduct); // event triggered when user
												// clicks on edit button and a
												// call is made to editProduct
												// function

$(document).on('click', '#submit-edit', function(e) { // event triggered when
														// user clicks on
														// (update/add) product
														// button
	var type = $('#submit-edit').text();

	if (type == 'Update') {
		var productID = $('#submit-edit').data('productId'); // updateProduct
																// function is
																// called when
																// the request
																// is to update
																// the product
		updateProduct(productID);
	} else { // addProduct function is called when the request is to update
				// the product
		addProduct();
	}
});

/*******************************************************************************
 * Adding new product to database functionality starts here
 ******************************************************************************/
function addProduct() {
	var pname = $.trim($('#ProductName').val());
	var pcategory = $.trim($('#Category').val());
	var pprice = $.trim($('#Price').val());
	var pdesc = $.trim($('#Description').val());

	if (pname.length == 0 || pcategory.length == 0 || pprice.length == 0
			|| pdesc.length == 0) {
		$('#add-product-error').removeClass('alert-success').addClass(
				'alert-danger');
		$('#add-product-error').html('Please fill all fields..');
		$('#add-product-error').css('display', 'flex');
		return false;
	}
	$.ajax({
		type : "POST",
		dataType : "json",
		data : {
			name : $('#ProductName').val(),
			category : $('#Category').val(),
			description : $('#Description').val(),
			price : $('#Price').val()
		},
		url : 'http://localhost:3000/product',
		success : function() { // displaying success message in case of adding
								// new product is successful
			$('#add-product-error').addClass('alert-success').removeClass(
					'alert-danger');
			$('#add-product-error').html('Product added successfully');
			$('#add-product-error').css('display', 'flex');
			$('#add-product-error').delay(2000).fadeOut('slow');
			$('.form-group').find("input[type=text], textarea").val("");
			$('#ProductsList').empty();
			$('#draggablezone').empty();
			
			setTimeout(getProducts(), 500); // To make sure the product is
											// successfully saved in database
											// before showing the product list
											// to end user again
		},
		error : function(jqXHR, exception) { // displaying error message in
												// case of exception in
												// connecting to the database
			$('#add-product-error').removeClass('alert-success').addClass(
					'alert-danger');
			$('#add-product-error').html(
					'Error in adding product. please try after sometime');
			$('#add-product-error').css('display', 'flex');
			$('#add-product-error').delay(2000).fadeOut('slow');
			$('.form-group').find("input[type=text], textarea").val("");
		}
	});
}
/*******************************************************************************
 * Adding new product to database functionality ends here
 ******************************************************************************/

/*******************************************************************************
 * Removing product from database functionality starts here
 ******************************************************************************/
$('#confirm-delete').on('click', '#delete', function(e) { // Event triggered
															// when the user
															// clicks on delete
															// button and a call
															// is made to
															// removeProduct()
															// function to
															// delete the
															// product
	var productID = $(this).data('productId');
	removeProduct(productID);
});

$('#confirm-delete').on('show.bs.modal', function(e) {
	var buttonID = e.relatedTarget['id'];
	var buttonArray = buttonID.split("-");
	var productID = buttonArray[1];
	$('#delete', this).data('productId', productID);
});

function removeProduct(id) { // Function call to delete the product

	$
			.ajax({
				type : "DELETE",
				dataType : "json",
				url : 'http://localhost:3000/product/' + id,
				success : function() {
					$('#remove-success').removeClass('alert-danger').addClass(
							'alert-success');
					$('#remove-success').html('Product successfully removed');
					$('#remove-success').css('display', 'flex');
					$('#remove-success').delay(2000).fadeOut('slow');
					$('#ProductsList').empty();
					$('#draggablezone').empty();
					getProducts();
				},
				error : function(jqXHR, exception) { // displaying error
														// message in case of
														// exception in
														// connecting to the
														// database
					$('#remove-success').css('display', 'flex');
					$('#remove-success')
							.html(
									"Error in deleting the product. Please try after sometime");
					$('#remove-success').delay(2000).fadeOut('slow');
				}
			});
}

/*******************************************************************************
 * Removing product from database functionality ends here
 ******************************************************************************/

/*******************************************************************************
 * Updating product functionality starts here
 ******************************************************************************/

/* Update Product */
function editProduct(event) { // This function converts form to edit mode
	var productID = $(this).parent().parent().attr('id');
	var ProductName = $('#name-' + productID).text();
	var description = $('#description-' + productID).text();
	var category = $('#category-' + productID).text();
	var price = $('#price-' + productID).text().replace('Rs:', '').trim();
	$('#ProductName').val(ProductName);
	$('#Description').val(description);
	$('#Category').val(category);
	$('#Price').val(price);
	$('#submit-edit').html("Update");
	$('.list-group-item').attr('id', productID);
	$('#ProductName').focus();
}

function updateProduct(productID) { // This function is called once all the
									// updates are made by the user and converts
									// the form to normal mode again
	var productID = $('.list-group-item').attr('id');
	var pname = $('#ProductName').val();
	var pcategory = $('#Category').val();
	var pprice = $('#Price').val();
	var pdesc = $('#Description').val();

	if (pname.length == 0 || pcategory.length == 0 || pprice.length == 0
			|| pdesc.length == 0) {
		$('#add-product-error').removeClass('alert-success').addClass(
				'alert-danger');
		$('#add-product-error').html('Please fill all fields..');
		$('#add-product-error').css('display', 'flex');
		return false;
	}

	$
			.ajax({
				type : "PUT",
				dataType : "json",
				data : {
					name : $('#ProductName').val(),
					category : $('#Category').val(),
					description : $('#Description').val(),
					price : $('#Price').val()
				},
				url : 'http://localhost:3000/product/' + productID,
				success : function() {
					$('#add-product-error').addClass('alert-success')
							.removeClass('alert-danger');
					$('#add-product-error').html('Successfully Updated');
					$('#submit-edit').html("Submit");
					$('#add-product-error').css('display', 'flex');
					$('.form-group').find("input[type=text], textarea").val("");
					$('#add-product-error').delay(2000).fadeOut('slow');
					$('#ProductsList').empty();
					$('#draggablezone').empty();
					
					getProducts();
				},
				error : function(jqXHR, exception) { // displaying error
														// message in case of
														// exception in
														// connecting to the
														// database
					$('#add-product-error').css('display', 'flex');
					$('#add-product-error')
							.html(
									"Error in updating the product. Please try after sometime");
					$('#add-product-error').delay(2000).fadeOut('slow');
				}
			});
}

$(document).on('click', '#cancel', function(e) {
	$('.form-group').find("input[type=text], textarea").val("");
	$('#submit-edit').html("Submit");
	$('#add-product-error').css('display', 'none');
})
/*******************************************************************************
 * Upating product functionality ends here
 ******************************************************************************/

/*******************************************************************************
 *  Drag Drop components starts here
 ******************************************************************************/   
 function allowDrop(ev) {

    ev.preventDefault();
						}

function drag(ev) 		{  


    ev.dataTransfer.setData("text", ev.target.id);
						}

function drop(ev) 		{


    ev.preventDefault();
 
	var data = ev.dataTransfer.getData("text");
	var ID=document.getElementById(data);
	document.getElementById(data).setAttribute('draggable', false);
	$(ID).append('<i id="Icon_'+data+'"onclick="removeDropzoneElement(this.id)" class="fa fa-times alert-danger" aria-hidden="true"></i>')
	ev.target.appendChild(document.getElementById(data));
	
	DragSearchPrd(data);	
	
						}
 
 /*******************************************************************************
 *  Drag Drop components ends here
 ******************************************************************************/  
 
 
 
 
/*******************************************************************************
 * Drag Drop and Search functionality starts here
 ******************************************************************************/  
function DragSearchPrd(Prdid)
	{


		var searchTextFlag=true;
		
		var droppablezone=$("#droppablezone > a");
		var droppablezonecount=$("#droppablezone > a").length;
		var prodlistdiv=$("#ProductsList > div");
		
		if (Prdid=='searchText'){

			var SearchElement=($('#'+Prdid).val());
			SearchElement=SearchElement.toLowerCase();
			var searchTxt=($('#'+Prdid).val().length);
								}

			if(searchTxt==0 && droppablezonecount==0)
								{
			$("#ProductsList > div").css("display","");
			entryIndicator=true;
								}
			else if(searchTxt==0 && droppablezonecount>0)
							{
			$("#ProductsList > div").css("display","none");
			$.each(droppablezone, function(increment, dropzoneElement) {

			$.each(prodlistdiv, function(i, proddivlist) {
							
						if(($(dropzoneElement).text())==($(proddivlist).find('label').text()) )
								{
						$(proddivlist).css("display","");
								}
						
														});
																		});

							}
				else{
				
				if (entryIndicator){
				 $("#ProductsList > div").css("display","none");
									}
				
				 if (searchTxt>=0){
						 $("#ProductsList > div").css("display","none");
						   $.each(prodlistdiv, function(i, proddivlist) {
							
							 
						if($(proddivlist).find('label').text().toLowerCase().indexOf(SearchElement)!=-1 || 
						($(proddivlist).find('p').text().toLowerCase()).indexOf(SearchElement)!=-1 ||
						($(proddivlist).find('h4').text().toLowerCase()).indexOf(SearchElement)!=-1 )
								{
						
						$(proddivlist).css("display", "");
							 searchTextFlag=false;
							}
							
							 
						  });
						  if (searchTextFlag){
						   $('#remove-success').addClass('alert-success').removeClass('alert-danger');
							$('#remove-success').html('Sorry, we dont have it');
							$('#remove-success').css('display', 'flex');
							$('#remove-success').delay(3500).fadeOut('slow');
														  
											}
						  
									}
				
			$.each(droppablezone, function(increment, dropzoneElement) {

			$.each(prodlistdiv, function(i, proddivlist) {
							
						if(($(dropzoneElement).text())==($(proddivlist).find('label').text()) )
								{			
							
						$(proddivlist).css("display","");
						
							}
						
														});
																		});
						
			entryIndicator=false;
						
				}

}

/*******************************************************************************
 * Drag Drop and Search product functionality ends here
 ******************************************************************************/ 
 
 
 /*******************************************************************************
 * Remove product from Drop zone functionality starts here
 ******************************************************************************/ 
 function removeDropzoneElement(btn){

var btnid=btn.substring(5);
var btnvalue=btnid.substring(9);

var prodlistdiv=$("#ProductsList > div");
var dropzoneEmptycheck=$("#droppablezone > a").length;
var serchTextlen=$('#searchText').val().length;

$.each(prodlistdiv, function(i, proddivlist) {
				
			if (dropzoneEmptycheck==1 && serchTextlen==0)	{
			$(proddivlist).css("display", "");
			counter=true;
			}
			else
			{
			if (btnvalue==($(proddivlist).find('label').text()) )
					{
			
			$(proddivlist).css("display", "none");
				
				}
			}
			
											});
document.getElementById(btnid).remove();
$('#draggablezone').append('<a id="'+btnid+'"type="button" class="btn btn-success pull-left"  draggable="true" ondragleave="allowDrop1(event)" ondragstart="drag(event)" style="margin-top:5px">'+btnvalue+'</a>')
	
									}
 /*******************************************************************************
 * Remove product from Drop zone functionality Ends here
 ******************************************************************************/
 
 
 

$(document).ready(function() {
	$("#searchText").keyup(function() {
		/*
		 * //Write your code here for the Free Text Search When the user types
		 * text in the search input box. As he types the text filter the
		 * products list Matching the following fields - Name - Description -
		 * Category - Price
		 * 
		 * The search string maybe present in any one of the fields anywhere in
		 * the content
		 * 
		 */

	});

});

// Code block for Image Upload

function readURL(input) {

	var tmp = $(input).attr('id');
	var imageidArray = tmp.split('-');
	var productID = imageidArray[1];

	if (input.files && input.files[0]) {
		var reader = new FileReader();
		reader.onload = function(e) {
			$('#image-' + productID).attr('src', e.target.result);
		}
		reader.readAsDataURL(input.files[0]);
	}
}

$(document).on('click', '.image', function(e) { // Function call when user
												// clicks on image to update
	var tmp = $(this).attr('id');
	var imageidArray = tmp.split('-');
	var productID = imageidArray[1];
	$("#imageInp-" + productID).click();
})

$(document).on(
		'click',
		'.href-cls',
		function(e) { // Function call when user clicks on upload button
			var tmp = $(this).attr('id');
			var productArray = tmp.split('-');
			var productID = productArray[1];

			if (!$('#imageInp-' + productID).val()) {
				$('#remove-success').addClass('alert-danger').removeClass(
						'alert-success');
				$('#remove-success').css('display', 'flex');
				$('#remove-success').html(
						"please select the image to be updated ");
				$('#remove-success').delay(2000).fadeOut('slow');
				return false;
			}
			var formData = new FormData();
			formData.append('file', $('#imageInp-' + productID)[0].files[0],
					productID + '_Product.png');
			$.ajax(
					{
						type : "PUT",
						data : formData,
						url : 'http://localhost:3000/product/' + productID
								+ '/ProductImg',
						contentType : false,
						processData : false
					})
					.done(
							function() {
								$('#remove-success')
										.removeClass('alert-danger').addClass(
												'alert-success');
								$('#remove-success').css('display', 'flex');
								$('#remove-success').html(
										"Image successfully updated");
								$('#remove-success').delay(2000)
										.fadeOut('slow');
							})
		});
